using System.Collections;
using System.Collections.Generic;
using UnityEngine;
// using WorldPart;

public class Move : MonoBehaviour
{
    // public WorldPart posX;
    // public WorldPart posZ;
    public GameObject Player;
    // [SerializeField] Vector3 move;

    void start()
    {
        
        // WorldPart worldPart = go.GetComponent<WorldPart>();
        // float posX = worldPart.posZ;
    }

    void FixedUpdate()
    {
        float PlPosX = Player.transform.position.x;
        // while (PlPosX < posX)
        // {

        // }
    }
}
