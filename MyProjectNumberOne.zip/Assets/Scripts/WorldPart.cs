using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.IO;

public class WorldPart : MonoBehaviour
{
    public Material PartOn;
    public Material PartOff;
    public float PosZ;
    void OnMouseEnter()
    {
        GetComponent<Renderer>().material = PartOff;
        // Debug.Log(GetComponent<Renderer>().transform.position);
    }

    public void OnMouseDown()
    {
        float posZ = GetComponent<Renderer>().transform.position.z;
        float posX = GetComponent<Renderer>().transform.position.x;
        Debug.Log("\nposZ = " + posZ + " posX = " + posX);
    }

    void OnMouseExit()
    {
        GetComponent<Renderer>().material = PartOn;
    }
}